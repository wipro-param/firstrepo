package wipro.com.myfirstapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void CreateEvent (View view)
    {
        Intent intent = new Intent(MainActivity.this, CreateEvent.class);
        startActivity(intent);
    }
    public void StartEvent (View view)
    {
        Intent intent = new Intent(MainActivity.this, StartEvent.class);
        startActivity(intent);
    }
    public void EndEvent (View view)
    {
        Intent intent = new Intent(MainActivity.this, EndEvent.class);
        startActivity(intent);
    }

}
