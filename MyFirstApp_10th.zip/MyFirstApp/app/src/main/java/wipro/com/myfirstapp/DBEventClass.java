package wipro.com.myfirstapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by PA391006 on 05/10/2017.
 */

public class DBEventClass extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "Wicruit.db";
    public static final String EVENTS_TABLE_NAME = "events_table";
    public static final String STUDENT_TABLE_NAME = "student_table";

    public static final String Event_Table_COL_0 = "ID";
    public static final String Event_Table_COL_1 = "TITLE";
    public static final String Event_Table_COL_2 = "TYPE";
    public static final String Event_Table_COL_3 = "LOCATION";
    public static final String Event_Table_COL_4 = "STARTDATE";
    public static final String Event_Table_COL_5 = "EVENTSTATUS";
    public static final String Event_Table_COL_6 = "EVENTATTENDED";

    public static final String Student_Table_COL_1 = "ID";
    public static final String Student_Table_COL_2 = "FIRSTNAME";
    public static final String Student_Table_COL_3 = "SURNAME";
    public static final String Student_Table_COL_4 = "EMAILADDRESS";
    public static final String Student_Table_COL_5 = "TYPEOFDEGREE";
    public static final String Student_Table_COL_6 = "COURSETITLE";
    public static final String Student_Table_COL_7 = "YEAROFGRAD";
    public static final String Student_Table_COL_8 = "PASSTYPE";


    public DBEventClass(Context context)
    {
         super(context, DATABASE_NAME, null, 1);
    }

@Override
public void onCreate(SQLiteDatabase db) {
    db.execSQL("create table " + STUDENT_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,FIRSTNAME TEXT,SURNAME TEXT,EMAILADDRESS TEXT,TYPEOFDEGREE TEXT,COURSETITLE TEXT,YEAROFGRAD TEXT,PASSTYPE TEXT)");
    db.execSQL("create table " + EVENTS_TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,TITLE TEXT,TYPE TEXT,LOCATION TEXT,STARTDATE TEXT, EVENTSTATUS TEXT, EVENTATTENDED TEXT)");

}

@Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion){
    db.execSQL("DROP TABLE IF EXISTS "+ EVENTS_TABLE_NAME);
    db.execSQL("DROP TABLE IF EXISTS "+ STUDENT_TABLE_NAME);
    onCreate(db);
}

public void insertData(String title,String type, String location, String startdate, String status) {
    SQLiteDatabase db = this.getWritableDatabase();//create database and table
    ContentValues contentValues = new ContentValues();
    contentValues.put(Event_Table_COL_1, title);
    contentValues.put(Event_Table_COL_2, type);
    contentValues.put(Event_Table_COL_3, location);
    contentValues.put(Event_Table_COL_4, startdate);
    contentValues.put(Event_Table_COL_5, status);
    contentValues.put(Event_Table_COL_6, "Not Attended");

    db.insert(EVENTS_TABLE_NAME, null, contentValues);
    db.close();
}

    public void insertStudentData(String firstname, String surname, String email, String typeofdeg, String coursetitle, String yearofgrad, String passtype){
        SQLiteDatabase db = this.getWritableDatabase();//create database and table
        ContentValues contentValues = new ContentValues();

        contentValues.put(Student_Table_COL_2, firstname);
        contentValues.put(Student_Table_COL_3, surname);
        contentValues.put(Student_Table_COL_4, email);
        contentValues.put(Student_Table_COL_5, typeofdeg);
        contentValues.put(Student_Table_COL_6, coursetitle);
        contentValues.put(Student_Table_COL_7, yearofgrad);
        contentValues.put(Student_Table_COL_8, passtype);
        db.insert(STUDENT_TABLE_NAME, null, contentValues);
        db.close();


}
    public ArrayList<String> getAll(){
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String completedCheck = "Complete";
        try {
            String selectQuery = "SELECT * FROM " + EVENTS_TABLE_NAME + " where EVENTSTATUS ='" + completedCheck + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }


    public ArrayList<String> getEndAll(){
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String eventAttended = "Attended";
        try {
            String selectQuery = "SELECT * FROM " + EVENTS_TABLE_NAME + " where EVENTATTENDED ='" + eventAttended + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }

}

