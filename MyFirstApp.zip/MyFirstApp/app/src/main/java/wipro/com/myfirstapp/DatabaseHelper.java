package wipro.com.myfirstapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by PA391006 on 05/10/2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "wicruit.db";
    public static final String TABLE_NAME = "events_table";

    public static final String COL_1 = "ID";
    public static final String COL_2 = "TITLE";
    public static final String COL_3 = "TYPE";
    public static final String COL_4 = "LOCATION";
    public static final String COL_5 = "STARTDATE";
    public static final String COL_6 = "EVENTSTATUS";
    public static final String COL_7 = "EVENTATTENDED";


    public DatabaseHelper(Context context){
    super(context, DATABASE_NAME, null, 1);
}

@Override
public void onCreate(SQLiteDatabase db) {
    db.execSQL("create table " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT,TITLE TEXT,TYPE TEXT,LOCATION TEXT,STARTDATE TEXT, EVENTSTATUS TEXT, EVENTATTENDED TEXT)");
}

@Override
    public void onUpgrade (SQLiteDatabase db, int oldVersion, int newVersion){
    db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    onCreate(db);
}

public void insertData(String title,String type, String location, String startdate, String status){
    SQLiteDatabase db = this.getWritableDatabase();//create database and table
    ContentValues contentValues = new ContentValues();
    contentValues.put(COL_2, title);
    contentValues.put(COL_3, type);
    contentValues.put(COL_4, location);
    contentValues.put(COL_5, startdate);
    contentValues.put(COL_6, status);
    contentValues.put(COL_7, "Not Attended");


    db.insert(TABLE_NAME, null, contentValues);

}
    public ArrayList<String> getAll(){
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String completedCheck = "Complete";
        try {
            String selectQuery = "SELECT * FROM " + TABLE_NAME + " where EVENTSTATUS ='" + completedCheck + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }


    public ArrayList<String> getEndAll(){
        ArrayList<String> list = new ArrayList<String>();
        SQLiteDatabase db = this.getReadableDatabase();
        db.beginTransaction();

        String eventAttended = "Attended";
        try {
            String selectQuery = "SELECT * FROM " + TABLE_NAME + " where EVENTATTENDED ='" + eventAttended + "'";
            Cursor cursor = db.rawQuery(selectQuery, null);


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndex("TITLE"));
                    list.add(title);
                }
            }
            db.setTransactionSuccessful();
        }catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            db.endTransaction();
            db.close();
        }
        return list;
    }

}

