package wipro.com.myfirstapp;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.util.ArrayList;

public class StartEvent extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_event);
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        ArrayList<String> listPro =databaseHelper.getAll();
        Spinner sp = (Spinner)findViewById(R.id.startEventSpinner);
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,R.layout.spinner_layout,R.id.txt,listPro);
        sp.setAdapter(adapter);
    }


}
