package com.wipro.wicruit;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class StartEvent extends AppCompatActivity {

    DatabaseClass myDB;
    Button StartAct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_event);

        myDB = new DatabaseClass(this);

        DatabaseClass databaseHelper = new DatabaseClass(this);
        ArrayList<String> listPro = databaseHelper.getAll();
        final Spinner sp = (Spinner) findViewById(R.id.startEventSpinner);


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spinner_layout, R.id.txt, listPro);
        sp.setAdapter(adapter);

        // saves selected drop down to a string value and saves into a SharedPreference
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(
                    AdapterView<?> adapterView, View view,
                    int i, long l) {
                final String Value = sp.getSelectedItem().toString();

                // storing shared preference
                SharedPreferences sharedp;
                SharedPreferences.Editor edit;
                sharedp = getSharedPreferences("events", MODE_PRIVATE);
                edit = sharedp.edit();
                edit.putString("choice", Value);
                edit.commit();


                final String EventStartedTxt = "Attended";
                StartAct = (Button) findViewById(R.id.startEventBtn);


                StartAct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        myDB.startEvent(EventStartedTxt, Value);
                        Intent intent = new Intent(StartEvent.this, StudentRegisterScreen.class);
                        startActivity(intent);
                    }
                });


            }

            public void onNothingSelected(
                    AdapterView<?> adapterView) {
            }


        });
    }

    public void StartEvent(View view) {

    }


}
