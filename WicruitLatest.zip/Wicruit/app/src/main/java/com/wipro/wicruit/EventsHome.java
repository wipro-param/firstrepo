package com.wipro.wicruit;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class EventsHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.events_home);
    }

   public void CreateEvent (View view)
    {
        Intent intent = new Intent(EventsHome.this, CreateEvent.class);
        startActivity(intent);
    }
    public void StartEvent (View view)
    {
        Intent intent = new Intent(EventsHome.this, StartEvent.class);
        startActivity(intent);
    }
    public void EndEvent (View view)
    {
        Intent intent = new Intent(EventsHome.this, EndEvent.class);
        startActivity(intent);
    }
}
