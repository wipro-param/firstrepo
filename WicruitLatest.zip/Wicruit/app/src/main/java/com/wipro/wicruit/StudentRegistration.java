package com.wipro.wicruit;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class StudentRegistration extends AppCompatActivity {

    DatabaseClass myDB1;
    Spinner typeOf;
    Spinner passW;
    Button Reset;

    EditText etFirstName, etSurname, etEmail, etCourseTitle, etYearOfGrad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_registration);

        myDB1 = new DatabaseClass(this);

        Button Submit = (Button) this.findViewById(R.id.submitBtn);
        Reset = (Button) this.findViewById(R.id.ResetBtn);

        // Getting shared Preference and Storing it to the Title
        SharedPreferences sharedp = getSharedPreferences("events", MODE_PRIVATE);
        final String Choice = sharedp.getString("choice", "");
        TextView title = (TextView)findViewById(R.id.textView3);
        title.setText(Choice);


        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etFirstName.setText("");
                etSurname.setText("");
                etEmail.setText("");
                etCourseTitle.setText("");
                etYearOfGrad.setText("");
            }
        });


        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 etFirstName = (EditText) findViewById(R.id.firstNameET);
                String FirstName = etFirstName.getText().toString();

                etSurname = (EditText) findViewById(R.id.SurnameET);
                String Surname = etSurname.getText().toString();

                etEmail = (EditText) findViewById(R.id.EmaileET);
                String Email = etEmail.getText().toString();

                Spinner spTypeOfDeg = (Spinner) findViewById(R.id.spinnerToD);
                String TypeOfDegree = spTypeOfDeg.getSelectedItem().toString();

                etCourseTitle = (EditText) findViewById(R.id.CourseTitleET);
                String CourseTitle = etCourseTitle.getText().toString();

                etYearOfGrad = (EditText) findViewById(R.id.YearOfGradeET);
                String YearOfGrad = etYearOfGrad.getText().toString();

                Spinner spPassType = (Spinner) findViewById(R.id.spinnerPass);
                String PassType = spPassType.getSelectedItem().toString();

                myDB1.insertStudentData(FirstName,Surname,Email,TypeOfDegree,CourseTitle,YearOfGrad,PassType, Choice);

                Toast.makeText(StudentRegistration.this, FirstName + " " + TypeOfDegree + " " + CourseTitle + " " + PassType, Toast.LENGTH_LONG).show();
                Intent intent = new Intent(StudentRegistration.this, StudentRegisterScreen.class);
                startActivity(intent);
            }
        });

        typeOf = (Spinner) findViewById(R.id.spinnerToD);
        passW = (Spinner) findViewById(R.id.spinnerPass);

        ArrayList<String> typeOfDegree = new ArrayList<String>();
        typeOfDegree.add("Type of Degree");
        typeOfDegree.add("BSc");
        typeOfDegree.add("BA");
        typeOfDegree.add("BEng");
        typeOfDegree.add("MSc");
        typeOfDegree.add("MA");
        typeOfDegree.add("MEd");
        typeOfDegree.add("LLM");
        typeOfDegree.add("MBA");
        typeOfDegree.add("MRes");
        typeOfDegree.add("PHD");

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, typeOfDegree);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        typeOf.setAdapter(adapter);

        ArrayList<String> typeOfPass = new ArrayList<String>();
        typeOfPass.add("Type of Passport");
        typeOfPass.add("UK");
        typeOfPass.add("EU");
        typeOfPass.add("INDIAN");


        ArrayAdapter adapter1 = new ArrayAdapter(this, android.R.layout.simple_spinner_item, typeOfPass);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        passW.setAdapter(adapter1);
    }

    public void ResetInput(){

    }
}
